package com.mertvy.winlocker

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val password = "FlexDm2026"
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 40, 36, 40)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(12, 35, 17), Color.BLACK, Color.BLACK)
            )
        }

        val title = TextView(this).apply {
            text = "MERTVY WINLOCKER"
            textSize = 30f
            setTextColor(Color.rgb(55, 230, 90))
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        val subtitle = TextView(this).apply {
            text = "SAFE DEMONSTRATION MODE"
            textSize = 12f
            setTextColor(Color.rgb(105, 145, 112))
            gravity = Gravity.CENTER
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            background = GradientDrawable().apply {
                setColor(Color.rgb(3, 7, 4))
                setStroke(2, Color.rgb(30, 100, 43))
                cornerRadius = 18f
            }
        }

        val locked = TextView(this).apply {
            text = "WINDOW LOCKED"
            textSize = 22f
            setTextColor(Color.rgb(55, 220, 80))
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        val info = TextView(this).apply {
            text = "Введите пароль для разблокировки"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 18)
        }

        val input = EditText(this).apply {
            hint = "Пароль"
            textSize = 18f
            gravity = Gravity.CENTER
            setSingleLine(true)
            inputType = 0x81
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(90, 110, 94))
            background = GradientDrawable().apply {
                setColor(Color.rgb(8, 17, 10))
                setStroke(2, Color.rgb(40, 120, 55))
                cornerRadius = 12f
            }
            setPadding(18, 0, 18, 0)
        }

        val button = Button(this).apply {
            text = "РАЗБЛОКИРОВАТЬ"
            textSize = 14f
            setTextColor(Color.rgb(85, 245, 115))
            background = GradientDrawable().apply {
                setColor(Color.rgb(15, 55, 24))
                setStroke(2, Color.rgb(45, 190, 70))
                cornerRadius = 12f
            }
        }

        status = TextView(this).apply {
            text = "Ожидание пароля..."
            textSize = 13f
            setTextColor(Color.rgb(95, 125, 100))
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        }

        button.setOnClickListener {
            if (input.text.toString() == password) {
                status.text = "ДОСТУП РАЗРЕШЁН"
                status.setTextColor(Color.rgb(50, 255, 80))
                button.isEnabled = false
                input.isEnabled = false
                window.decorView.animate().alpha(0f).setDuration(450).withEndAction { finish() }.start()
            } else {
                status.text = "НЕВЕРНЫЙ ПАРОЛЬ"
                status.setTextColor(Color.rgb(255, 75, 75))
                input.text.clear()
                input.requestFocus()
                panel.animate().translationX(12f).setDuration(50).withEndAction {
                    panel.animate().translationX(-12f).setDuration(50).withEndAction {
                        panel.animate().translationX(0f).setDuration(50).start()
                    }.start()
                }.start()
            }
        }

        panel.addView(locked, LinearLayout.LayoutParams(-1, -2))
        panel.addView(info, LinearLayout.LayoutParams(-1, -2))
        panel.addView(input, LinearLayout.LayoutParams(-1, 58))
        panel.addView(button, LinearLayout.LayoutParams(-1, 58).apply { topMargin = 18 })
        panel.addView(status, LinearLayout.LayoutParams(-1, -2))

        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 30 })
        root.addView(panel, LinearLayout.LayoutParams(-1, -2))

        val footer = TextView(this).apply {
            text = "Демонстрационный режим • Android и файлы не изменяются"
            textSize = 11f
            setTextColor(Color.rgb(75, 90, 78))
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }
        root.addView(footer, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)

        val pulse = ValueAnimator.ofObject(
            ArgbEvaluator(),
            Color.rgb(45, 190, 65),
            Color.rgb(100, 255, 120)
        ).apply {
            duration = 900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { title.setTextColor(it.animatedValue as Int) }
        }
        pulse.start()
    }
}
